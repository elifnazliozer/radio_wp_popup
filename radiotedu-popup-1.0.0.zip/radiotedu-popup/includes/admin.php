<?php
// Yönetim paneli: popup düzenleme ekranı, liste sütunları, önizleme, kopyalama ve istatistik sıfırlama

if (!defined('ABSPATH')) {
    exit;
}

const RTP_DAYS = [1 => 'Pzt', 2 => 'Sal', 3 => 'Çar', 4 => 'Per', 5 => 'Cum', 6 => 'Cmt', 0 => 'Paz'];

/* ------------------------------------------------------------------ */
/* varlıklar                                                           */
/* ------------------------------------------------------------------ */

add_action('admin_enqueue_scripts', function ($hook) {
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== RTP_POST_TYPE) {
        return;
    }
    wp_enqueue_style('rtp-admin', RTP_URL . 'assets/admin.css', [], rtp_asset_version('admin.css'));
    if ($hook === 'post.php' || $hook === 'post-new.php') {
        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('rtp-admin', RTP_URL . 'assets/admin.js', ['jquery', 'wp-color-picker'], rtp_asset_version('admin.js'), true);
    }
});

/* ------------------------------------------------------------------ */
/* yardımcılar                                                         */
/* ------------------------------------------------------------------ */

function rtp_field_name($key) {
    return 'rtp[' . $key . ']';
}

function rtp_select($key, $value, array $choices, $id = '') {
    echo '<select name="' . esc_attr(rtp_field_name($key)) . '"' . ($id ? ' id="' . esc_attr($id) . '"' : '') . ' data-rtp="' . esc_attr($key) . '">';
    foreach ($choices as $k => $label) {
        echo '<option value="' . esc_attr($k) . '"' . selected($value, $k, false) . '>' . esc_html($label) . '</option>';
    }
    echo '</select>';
}

function rtp_checkbox($key, $value, $label) {
    echo '<label><input type="checkbox" name="' . esc_attr(rtp_field_name($key)) . '" value="1"' . checked($value, 1, false) . '> ' . esc_html($label) . '</label>';
}

function rtp_number($key, $value, $min, $max, $suffix = '') {
    echo '<input type="number" class="small-text" name="' . esc_attr(rtp_field_name($key)) . '" value="' . esc_attr($value) . '" min="' . (int) $min . '" max="' . (int) $max . '"> ' . esc_html($suffix);
}

function rtp_preview_url($post_id, $lang = 'tr') {
    return add_query_arg([
        'rtp_preview' => $post_id,
        '_rtpnonce'   => wp_create_nonce('rtp_preview_' . $post_id),
    ], home_url($lang === 'en' ? '/en/' : '/'));
}

function rtp_format_local($local) {
    if ($local === '') {
        return '';
    }
    $ts = rtp_timestamp($local);
    return $ts ? wp_date('j M Y H:i', $ts) : '';
}

// kullanıcıya gösterilecek durum etiketi
function rtp_status_label(WP_Post $post, array $s) {
    if ($post->post_status !== 'publish') {
        return ['draft', $post->post_status === 'future' ? 'Zamanlanmış yazı' : 'Taslak'];
    }
    if (!rtp_options()['enabled']) {
        return ['off', 'Durduruldu (genel ayar)'];
    }
    if ($s['type'] === 'image' && !rtp_has_images($s, 'tr') && !rtp_has_images($s, 'en')) {
        return ['warn', 'Görsel yok'];
    }
    switch (rtp_schedule_state($s)) {
        case 'scheduled':
            return ['scheduled', 'Başlayacak'];
        case 'ended':
            return ['ended', 'Sona erdi'];
    }
    return rtp_in_window($s) ? ['live', 'Yayında'] : ['waiting', 'Yayında · şu an gün/saat dışında'];
}

// bilgi notları: hata değil, ama bilinmesi iyi olan durumlar
function rtp_notes(array $s) {
    $n = [];
    if ($s['type'] === 'image' && rtp_has_images($s, 'tr') && !rtp_has_images($s, 'en') && $s['language'] !== 'tr') {
        $n[] = 'İngilizce görsel seçilmedi: İngilizce sayfalarda Türkçe görsel gösterilecek.';
    }
    if ($s['type'] === 'image' && !rtp_has_images($s, 'tr') && rtp_has_images($s, 'en') && $s['language'] !== 'en') {
        $n[] = 'Türkçe görsel seçilmedi: Türkçe sayfalarda popup gösterilmeyecek. Türkçe görsel ekleyin ya da Dil ayarını "Yalnızca İngilizce sayfalar" yapın.';
    }
    return $n;
}

// kaydedilmiş ayarlardaki sorunlar (düzenleme ekranında uyarı olarak gösterilir)
function rtp_warnings(array $s) {
    $w = [];
    if ($s['type'] === 'image' && !rtp_has_images($s, 'tr') && !rtp_has_images($s, 'en')) {
        $w[] = 'Görsel seçilmedi. Görselsiz bir görsel popup\'ı gösterilmez.';
    }
    $start = rtp_timestamp($s['start']);
    $end = rtp_timestamp($s['end']);
    if ($start !== null && $end !== null && $end <= $start) {
        $w[] = 'Bitiş zamanı başlangıçtan önce. Popup hiç gösterilmez.';
    }
    if ($end !== null && $end <= time()) {
        $w[] = 'Bitiş zamanı geçmiş. Popup artık gösterilmiyor.';
    }
    if ($s['pages'] === 'include' && $s['include_paths'] === '') {
        $w[] = '"Yalnızca şu adreslerde" seçili ama adres yazılmamış. Popup hiçbir sayfada gösterilmez.';
    }
    if ($s['type'] === 'content' && trim(wp_strip_all_tags($s['content'])) === '' && $s['button_text'] === '') {
        $w[] = 'İçerik boş.';
    }
    return $w;
}

/* ------------------------------------------------------------------ */
/* düzenleme ekranı                                                    */
/* ------------------------------------------------------------------ */

add_filter('enter_title_here', function ($text, $post) {
    return $post->post_type === RTP_POST_TYPE ? 'Popup adı (ör. Haftalık Gazete 12. sayı)' : $text;
}, 10, 2);

// yayınlanmış bir popup için: ne zaman görüneceği ve önizleme bağlantısı
function rtp_published_hint(WP_Post $post) {
    $s = rtp_get($post->ID);
    [$code] = rtp_status_label($post, $s);
    $parts = [];
    if ($code === 'scheduled') {
        $parts[] = 'Sitede ' . rtp_format_local($s['start']) . ' itibarıyla görünecek.';
    } elseif ($code === 'waiting') {
        $when = [];
        if ($s['days']) {
            $when[] = implode(', ', array_map(function ($d) { return RTP_DAYS[$d]; }, $s['days'])) . ' günleri';
        }
        if ($s['time_from']) {
            $when[] = 'saat ' . $s['time_from'] . '–' . $s['time_to'] . ' arasında';
        }
        $parts[] = 'Şu an gösterim zamanının dışında; sitede ' . implode(', ', $when) . ' görünecek.';
    } elseif ($code === 'ended') {
        $parts[] = 'Bitiş zamanı geçtiği için sitede görünmüyor.';
    } elseif ($code === 'warn') {
        $parts[] = 'Görsel seçilmediği için sitede görünmüyor.';
    } elseif ($code === 'live') {
        $parts[] = $s['pages'] === 'home' ? 'Ana sayfada görünüyor.' : 'Sitede görünüyor.';
    }
    $parts[] = 'Önizle: <a href="' . esc_url(rtp_preview_url($post->ID)) . '" target="_blank" rel="noopener">TR</a> · <a href="' . esc_url(rtp_preview_url($post->ID, 'en')) . '" target="_blank" rel="noopener">EN</a>';
    return ' ' . implode(' ', $parts);
}

add_filter('post_updated_messages', function ($messages) {
    $post = get_post();
    $hint = $post && $post->post_type === RTP_POST_TYPE && $post->post_status === 'publish' ? rtp_published_hint($post) : '';
    $messages[RTP_POST_TYPE] = [
        1  => 'Popup güncellendi.' . $hint,
        4  => 'Popup güncellendi.',
        6  => 'Popup yayınlandı.' . $hint,
        7  => 'Popup kaydedildi.',
        8  => 'Popup gönderildi.',
        9  => 'Popup zamanlandı.',
        10 => 'Popup taslağı güncellendi.',
    ];
    return $messages;
});

add_action('add_meta_boxes_' . RTP_POST_TYPE, function () {
    add_meta_box('rtp-content', '1 · Görsel', 'rtp_box_content', RTP_POST_TYPE, 'normal', 'high');
    add_meta_box('rtp-schedule', '2 · Ne zaman gösterilsin?', 'rtp_box_schedule', RTP_POST_TYPE, 'normal', 'high');
    add_meta_box('rtp-targeting', '3 · Nerede gösterilsin?', 'rtp_box_targeting', RTP_POST_TYPE, 'normal', 'high');
    add_meta_box('rtp-advanced', 'Gelişmiş ayarlar', 'rtp_box_advanced', RTP_POST_TYPE, 'normal', 'default');
    add_meta_box('rtp-stats', 'Özet ve istatistik', 'rtp_box_stats', RTP_POST_TYPE, 'side', 'high');
});

// gelişmiş ayarlar kutusu kapalı açılır: çoğu popup için dokunmaya gerek yok
add_filter('postbox_classes_' . RTP_POST_TYPE . '_rtp-advanced', function ($classes) {
    $classes[] = 'closed';
    return $classes;
});

function rtp_image_field($key, $attachment_id, $label, $help = '', $big = false) {
    $url = $attachment_id ? wp_get_attachment_image_url($attachment_id, 'medium') : '';
    ?>
    <div class="rtp-image-field<?php echo $big ? ' rtp-image-big' : ''; ?>" data-rtp-image>
        <span class="rtp-label"><?php echo esc_html($label); ?></span>
        <button type="button" class="rtp-image-preview<?php echo $url ? ' has-image' : ''; ?>" data-rtp-pick aria-label="<?php echo esc_attr($label . ' seç'); ?>">
            <?php if ($url) : ?><img src="<?php echo esc_url($url); ?>" alt=""><?php else : ?><span class="rtp-image-empty"><span class="dashicons dashicons-format-image"></span>Görsel seç</span><?php endif; ?>
        </button>
        <input type="hidden" name="<?php echo esc_attr(rtp_field_name($key)); ?>" value="<?php echo esc_attr($attachment_id ?: ''); ?>">
        <span class="rtp-image-actions">
            <button type="button" class="button-link" data-rtp-pick<?php echo $attachment_id ? '' : ' hidden'; ?> data-rtp-change>Değiştir</button>
            <button type="button" class="button-link rtp-remove" data-rtp-remove<?php echo $attachment_id ? '' : ' hidden'; ?>>Kaldır</button>
        </span>
        <?php if ($help) : ?><span class="description"><?php echo esc_html($help); ?></span><?php endif; ?>
    </div>
    <?php
}

// bir dilin alanları: TR asıl içerik, EN boş bırakılan her alanda Türkçesini kullanır
function rtp_lang_panel(array $s, $lang) {
    $en = $lang === 'en';
    $k = function ($key) use ($en) { return $en ? $key . '_en' : $key; };
    $id = function ($key) use ($lang) { return 'rtp-' . $lang . '-' . $key; };
    $extraOpen = $s[$k('image_mobile')] || $s[$k('image_alt')] !== '';
    ?>
    <section class="rtp-lang rtp-lang-<?php echo esc_attr($lang); ?>">
        <header class="rtp-lang-head">
            <span class="rtp-lang-badge"><?php echo $en ? 'EN' : 'TR'; ?></span>
            <span><?php echo $en ? 'İngilizce sayfalar' : 'Türkçe sayfalar'; ?></span>
            <?php if ($en) : ?><span class="rtp-lang-hint">boş bırakılanlar Türkçeden alınır</span><?php endif; ?>
        </header>

        <?php if ($en) : ?>
            <p class="rtp-field"><label class="rtp-label" for="<?php echo esc_attr($id('title')); ?>">Başlık</label>
                <input id="<?php echo esc_attr($id('title')); ?>" type="text" class="widefat" name="rtp[title_en]" value="<?php echo esc_attr($s['title_en']); ?>" placeholder="Weekly TEDU · 02"></p>
        <?php endif; ?>

        <div data-rtp-show="type=image">
            <?php rtp_image_field($k('image_desktop'), $s[$k('image_desktop')], 'Görsel', '', true); ?>
            <p class="rtp-field"><label class="rtp-label" for="<?php echo esc_attr($id('link')); ?>">Tıklanınca açılacak adres</label>
                <input id="<?php echo esc_attr($id('link')); ?>" type="url" class="widefat" name="rtp[<?php echo esc_attr($k('link_url')); ?>]" value="<?php echo esc_attr($s[$k('link_url')]); ?>" placeholder="<?php echo $en ? 'https://radiotedu.com/en/...' : 'https://radiotedu.com/...'; ?>"></p>
            <details class="rtp-more"<?php echo $extraOpen ? ' open' : ''; ?>>
                <summary>Telefon için ayrı görsel, görsel açıklaması</summary>
                <?php rtp_image_field($k('image_mobile'), $s[$k('image_mobile')], 'Telefon görseli', 'Seçilmezse telefonda da yukarıdaki görsel kullanılır.'); ?>
                <p class="rtp-field"><label class="rtp-label" for="<?php echo esc_attr($id('alt')); ?>">Görsel açıklaması <span class="rtp-optional">ekran okuyucular için</span></label>
                    <input id="<?php echo esc_attr($id('alt')); ?>" type="text" class="widefat" name="rtp[<?php echo esc_attr($k('image_alt')); ?>]" value="<?php echo esc_attr($s[$k('image_alt')]); ?>" placeholder="<?php echo $en ? 'Weekly TEDU issue 2 is out' : 'Haftalık Gazete 2. sayı çıktı'; ?>"></p>
            </details>
        </div>

        <div data-rtp-show="type=content">
            <?php
            wp_editor($s[$k('content')], $en ? 'rtp_content_en_editor' : 'rtp_content_editor', [
                'textarea_name' => 'rtp[' . $k('content') . ']',
                'textarea_rows' => 7,
                'media_buttons' => true,
            ]);
            ?>
            <div class="rtp-row">
                <p class="rtp-field"><label class="rtp-label" for="<?php echo esc_attr($id('btn-text')); ?>">Buton yazısı</label>
                    <input id="<?php echo esc_attr($id('btn-text')); ?>" type="text" class="widefat" name="rtp[<?php echo esc_attr($k('button_text')); ?>]" value="<?php echo esc_attr($s[$k('button_text')]); ?>" placeholder="<?php echo $en ? 'Listen now' : 'Hemen dinle'; ?>"></p>
                <p class="rtp-field"><label class="rtp-label" for="<?php echo esc_attr($id('btn-url')); ?>">Buton adresi</label>
                    <input id="<?php echo esc_attr($id('btn-url')); ?>" type="url" class="widefat" name="rtp[<?php echo esc_attr($k('button_url')); ?>]" value="<?php echo esc_attr($s[$k('button_url')]); ?>"></p>
            </div>
        </div>
    </section>
    <?php
}

function rtp_box_content(WP_Post $post) {
    $s = rtp_get($post->ID);
    wp_nonce_field('rtp_save_' . $post->ID, 'rtp_nonce');
    // uyarılar yalnızca kaydedilmiş bir popup için gösterilir (yeni popup'ta henüz bir şey seçilmemiştir)
    if ($post->post_status !== 'auto-draft') {
        foreach (rtp_warnings($s) as $warning) {
            echo '<div class="notice notice-warning inline"><p>' . esc_html($warning) . '</p></div>';
        }
        foreach (rtp_notes($s) as $note) {
            echo '<div class="notice notice-info inline"><p>' . esc_html($note) . '</p></div>';
        }
    }
    ?>
    <div class="rtp-seg" role="radiogroup" aria-label="Popup türü">
        <label><input type="radio" name="rtp[type]" value="image" <?php checked($s['type'], 'image'); ?>><span>Görsel</span></label>
        <label><input type="radio" name="rtp[type]" value="content" <?php checked($s['type'], 'content'); ?>><span>Yazı ve buton</span></label>
    </div>
    <div class="rtp-langs">
        <?php rtp_lang_panel($s, 'tr'); ?>
        <?php rtp_lang_panel($s, 'en'); ?>
    </div>
    <?php
}

function rtp_box_schedule(WP_Post $post) {
    $s = rtp_get($post->ID);
    $windowOpen = $s['days'] || $s['time_from'] !== '';
    ?>
    <div class="rtp-row">
        <p class="rtp-field"><label class="rtp-label" for="rtp-start">Başlangıç</label>
            <input id="rtp-start" type="datetime-local" name="rtp[start]" value="<?php echo esc_attr($s['start']); ?>">
            <span class="description">Boşsa hemen başlar.</span></p>
        <p class="rtp-field"><label class="rtp-label" for="rtp-end">Bitiş</label>
            <input id="rtp-end" type="datetime-local" name="rtp[end]" value="<?php echo esc_attr($s['end']); ?>">
            <span class="description">Boşsa siz kapatana kadar sürer.</span></p>
    </div>
    <details class="rtp-more"<?php echo $windowOpen ? ' open' : ''; ?>>
        <summary>Yalnızca belirli günlerde ya da saatlerde göster</summary>
        <div class="rtp-field"><span class="rtp-label">Günler <span class="rtp-optional">hiçbiri seçilmezse her gün</span></span>
            <div class="rtp-days">
                <?php foreach (RTP_DAYS as $num => $label) : ?>
                    <label><input type="checkbox" name="rtp[days][]" value="<?php echo (int) $num; ?>" <?php checked(in_array($num, $s['days'], true)); ?>><span><?php echo esc_html($label); ?></span></label>
                <?php endforeach; ?>
            </div></div>
        <p class="rtp-field"><span class="rtp-label">Saat aralığı <span class="rtp-optional">boşsa gün boyu</span></span>
            <input type="time" name="rtp[time_from]" value="<?php echo esc_attr($s['time_from']); ?>" aria-label="Başlangıç saati">
            –
            <input type="time" name="rtp[time_to]" value="<?php echo esc_attr($s['time_to']); ?>" aria-label="Bitiş saati"></p>
    </details>
    <?php
}

function rtp_box_targeting(WP_Post $post) {
    $s = rtp_get($post->ID);
    $moreOpen = $s['language'] !== 'all' || $s['device'] !== 'all' || $s['audience'] !== 'all' || $s['exclude_paths'] !== '';
    $choices = [
        'all'     => ['Bütün sayfalar', 'Sitenin her yerinde'],
        'home'    => ['Yalnızca ana sayfa', 'Türkçe ve İngilizce ana sayfa'],
        'include' => ['Belirli sayfalar', 'Adreslerini siz yazarsınız'],
    ];
    ?>
    <div class="rtp-cards" role="radiogroup" aria-label="Sayfalar">
        <?php foreach ($choices as $value => $text) : ?>
            <label class="rtp-card"><input type="radio" name="rtp[pages]" value="<?php echo esc_attr($value); ?>" <?php checked($s['pages'], $value); ?>>
                <span><strong><?php echo esc_html($text[0]); ?></strong><small><?php echo esc_html($text[1]); ?></small></span></label>
        <?php endforeach; ?>
    </div>
    <p class="rtp-field" data-rtp-show="pages=include"><label class="rtp-label" for="rtp-include">Sayfa adresleri <span class="rtp-optional">her satıra bir tane · <code>*</code> = devamı ne olursa</span></label>
        <textarea id="rtp-include" name="rtp[include_paths]" rows="3" class="widefat code" placeholder="/podcastler/&#10;/podcast-bolumu/*"><?php echo esc_textarea($s['include_paths']); ?></textarea></p>
    <details class="rtp-more"<?php echo $moreOpen ? ' open' : ''; ?>>
        <summary>Dil, cihaz, ziyaretçi ve hariç tutulacak sayfalar</summary>
        <div class="rtp-row rtp-row-3">
            <p class="rtp-field"><label class="rtp-label" for="rtp-language">Dil</label>
                <?php rtp_select('language', $s['language'], ['all' => 'Türkçe ve İngilizce', 'tr' => 'Yalnızca Türkçe', 'en' => 'Yalnızca İngilizce'], 'rtp-language'); ?></p>
            <p class="rtp-field"><label class="rtp-label" for="rtp-device">Cihaz</label>
                <?php rtp_select('device', $s['device'], ['all' => 'Telefon ve bilgisayar', 'desktop' => 'Yalnızca bilgisayar', 'mobile' => 'Yalnızca telefon'], 'rtp-device'); ?></p>
            <p class="rtp-field"><label class="rtp-label" for="rtp-audience">Ziyaretçi</label>
                <?php rtp_select('audience', $s['audience'], ['all' => 'Herkes', 'guests' => 'Giriş yapmamış olanlar', 'members' => 'Giriş yapmış olanlar'], 'rtp-audience'); ?></p>
        </div>
        <p class="rtp-field"><label class="rtp-label" for="rtp-exclude">Gösterilmeyecek sayfalar <span class="rtp-optional">her satıra bir adres</span></label>
            <textarea id="rtp-exclude" name="rtp[exclude_paths]" rows="2" class="widefat code" placeholder="/hakkimizda/"><?php echo esc_textarea($s['exclude_paths']); ?></textarea></p>
    </details>
    <?php
}

function rtp_box_advanced(WP_Post $post) {
    $s = rtp_get($post->ID);
    ?>
    <p class="description rtp-advanced-intro">Varsayılanlar çoğu popup için uygundur: sayfa açıldıktan 2 saniye sonra, ortada, her ziyaretçiye günde bir kez.</p>
    <h4 class="rtp-subhead">Ne zaman açılsın, kaç kez gösterilsin</h4>
    <div class="rtp-row">
        <p class="rtp-field"><label class="rtp-label" for="rtp-trigger">Açılış</label>
            <?php rtp_select('trigger', $s['trigger'], ['delay' => 'Sayfa açıldıktan sonra', 'scroll' => 'Sayfa kaydırılınca', 'exit' => 'Ziyaretçi sayfadan çıkarken'], 'rtp-trigger'); ?>
            <span data-rtp-show="trigger=delay,exit"><?php rtp_number('delay', $s['delay'], 0, 600, 'saniye sonra'); ?></span>
            <span data-rtp-show="trigger=scroll">%<?php rtp_number('scroll', $s['scroll'], 1, 100, 'kaydırılınca'); ?></span></p>
        <p class="rtp-field"><label class="rtp-label" for="rtp-frequency">Aynı kişiye</label>
            <?php rtp_select('frequency', $s['frequency'], ['days' => 'Birkaç günde bir', 'session' => 'Her ziyarette bir kez', 'once' => 'Yalnızca bir kez', 'always' => 'Her sayfa açılışında'], 'rtp-frequency'); ?>
            <span data-rtp-show="frequency=days"><?php rtp_number('frequency_days', $s['frequency_days'], 1, 365, 'günde bir'); ?></span></p>
    </div>
    <p><?php rtp_checkbox('hide_after_click', $s['hide_after_click'], 'Bağlantıya tıklayana bir daha gösterme'); ?></p>
    <p><?php rtp_checkbox('link_new_tab', $s['link_new_tab'], 'Bağlantı yeni sekmede açılsın'); ?></p>

    <h4 class="rtp-subhead">Görünüm</h4>
    <div class="rtp-row">
        <p class="rtp-field"><label class="rtp-label" for="rtp-position">Konum</label>
            <?php rtp_select('position', $s['position'], ['center' => 'Ortada', 'bottom-right' => 'Sağ alt köşe', 'bottom-left' => 'Sol alt köşe', 'bottom-bar' => 'Altta bant'], 'rtp-position'); ?></p>
        <p class="rtp-field"><label class="rtp-label" for="rtp-animation">Animasyon</label>
            <?php rtp_select('animation', $s['animation'], ['zoom' => 'Büyüyerek', 'fade' => 'Belirerek', 'slide' => 'Aşağıdan kayarak', 'none' => 'Yok'], 'rtp-animation'); ?></p>
    </div>
    <p><?php rtp_checkbox('show_title', $s['show_title'], 'Popup adı sol üstte görünsün (sitedeki gazete penceresi gibi çerçeveli)'); ?></p>
    <div class="rtp-row rtp-row-3">
        <p class="rtp-field"><span class="rtp-label">Genişlik</span><?php rtp_number('width', $s['width'], 200, 1400, 'px'); ?> <span class="rtp-optional">telefonda</span> <?php rtp_number('mobile_width', $s['mobile_width'], 50, 100, '%'); ?></p>
        <p class="rtp-field"><span class="rtp-label">Köşe yuvarlaklığı</span><?php rtp_number('radius', $s['radius'], 0, 40, 'px'); ?></p>
        <p class="rtp-field"><span class="rtp-label">Kendiliğinden kapanma</span><?php rtp_number('auto_close', $s['auto_close'], 0, 600, 'sn (0 = kapanmaz)'); ?></p>
    </div>
    <div data-rtp-show="position=center">
        <p class="rtp-field"><span class="rtp-label">Arka plan</span>
            <input type="text" class="rtp-color" name="rtp[overlay_color]" value="<?php echo esc_attr($s['overlay_color']); ?>" data-default-color="#000000">
            <?php rtp_number('overlay_opacity', $s['overlay_opacity'], 0, 95, '% koyuluk'); ?></p>
        <p><?php rtp_checkbox('close_on_overlay', $s['close_on_overlay'], 'Arka plana tıklayınca kapansın'); ?></p>
    </div>
    <p class="rtp-field"><span class="rtp-label">Öncelik <span class="rtp-optional">aynı sayfada birden fazla popup varsa yüksek olan açılır</span></span><?php rtp_number('priority', $s['priority'], 0, 100); ?></p>
    <?php
}

// ayarların düz Türkçe özeti: "Ana sayfada, her gün 17:00–19:00 arası, günde bir kez görünür."
function rtp_summary(array $s) {
    $where = ['all' => 'Bütün sayfalarda', 'home' => 'Ana sayfada', 'include' => 'Seçtiğiniz sayfalarda'][$s['pages']];
    if ($s['language'] !== 'all') {
        $where .= $s['language'] === 'en' ? ' (yalnızca İngilizce)' : ' (yalnızca Türkçe)';
    }
    $parts = [$where];
    if ($s['start'] && $s['end']) {
        $parts[] = rtp_format_local($s['start']) . ' – ' . rtp_format_local($s['end']) . ' arası';
    } elseif ($s['start']) {
        $parts[] = rtp_format_local($s['start']) . ' itibarıyla';
    } elseif ($s['end']) {
        $parts[] = rtp_format_local($s['end']) . ' tarihine kadar';
    }
    $when = $s['days'] ? implode(', ', array_map(function ($d) { return RTP_DAYS[$d]; }, $s['days'])) . ' günleri' : ($s['time_from'] ? 'her gün' : '');
    if ($s['time_from']) {
        $when .= ' ' . $s['time_from'] . '–' . $s['time_to'] . ' arası';
    }
    if ($when) {
        $parts[] = trim($when);
    }
    if ($s['device'] !== 'all') {
        $parts[] = $s['device'] === 'mobile' ? 'yalnızca telefonda' : 'yalnızca bilgisayarda';
    }
    $trigger = ['delay' => $s['delay'] ? 'sayfa açıldıktan ' . $s['delay'] . ' sn sonra' : 'sayfa açılınca', 'scroll' => 'sayfanın %' . $s['scroll'] . '\'i kaydırılınca', 'exit' => 'ziyaretçi çıkarken'][$s['trigger']];
    $freq = ['always' => 'her seferinde', 'session' => 'her ziyarette bir kez', 'days' => $s['frequency_days'] > 1 ? $s['frequency_days'] . ' günde bir' : 'günde bir kez', 'once' => 'kişi başına bir kez'][$s['frequency']];
    $parts[] = $trigger;
    $parts[] = $freq;
    return implode(', ', $parts) . ' görünür.';
}

function rtp_box_stats(WP_Post $post) {
    $s = rtp_get($post->ID);
    [$code, $label] = rtp_status_label($post, $s);
    $st = rtp_stats($post->ID);
    echo '<p><span class="rtp-status rtp-status-' . esc_attr($code) . '">' . esc_html($label) . '</span></p>';
    if ($post->post_status !== 'auto-draft') {
        echo '<p class="rtp-summary">' . esc_html(rtp_summary($s)) . '</p>';
        echo '<p class="rtp-preview-buttons"><span class="rtp-label">Sitede önizle</span><a class="button" target="_blank" rel="noopener" href="' . esc_url(rtp_preview_url($post->ID)) . '">TR</a> <a class="button" target="_blank" rel="noopener" href="' . esc_url(rtp_preview_url($post->ID, 'en')) . '">EN</a></p>';
        echo '<p class="description">Kaydedilmiş hâli hemen açar; zamana bakmaz, istatistiğe sayılmaz.</p>';
    } else {
        echo '<p class="description">Görseli seçip zamanı belirleyin, sonra <strong>Yayınla</strong>\'ya basın.</p>';
    }
    if ($st['views'] || $st['clicks'] || $st['closes']) {
        echo '<div class="rtp-stats-grid"><div><strong>' . esc_html(number_format_i18n($st['views'])) . '</strong><span>görüntülenme</span></div>';
        echo '<div><strong>' . esc_html(number_format_i18n($st['clicks'])) . '</strong><span>tıklama</span></div>';
        echo '<div><strong>%' . esc_html(number_format_i18n($st['ctr'], 1)) . '</strong><span>tıklama oranı</span></div></div>';
        $daily = get_post_meta($post->ID, '_rtp_daily', true);
        if (is_array($daily) && $daily) {
            $last = array_slice($daily, -14, null, true);
            $max = max(1, max(array_map(function ($d) { return (int) ($d['view'] ?? 0); }, $last)));
            echo '<div class="rtp-chart" aria-label="Son 14 günün görüntülenmeleri">';
            foreach ($last as $day => $d) {
                $h = round(((int) ($d['view'] ?? 0)) / $max * 100);
                echo '<span style="height:' . (int) max(2, $h) . '%" title="' . esc_attr($day . ': ' . (int) ($d['view'] ?? 0) . ' görüntülenme, ' . (int) ($d['click'] ?? 0) . ' tıklama') . '"></span>';
            }
            echo '</div>';
        }
        $url = wp_nonce_url(admin_url('admin-post.php?action=rtp_reset&post=' . $post->ID), 'rtp_reset_' . $post->ID);
        echo '<p><a href="' . esc_url($url) . '" class="button-link-delete" onclick="return confirm(\'İstatistikler sıfırlansın mı?\')">İstatistikleri sıfırla</a></p>';
    }
}

add_action('save_post_' . RTP_POST_TYPE, function ($post_id, $post) {
    if (!isset($_POST['rtp_nonce']) || !wp_verify_nonce(sanitize_key(wp_unslash($_POST['rtp_nonce'])), 'rtp_save_' . $post_id)) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id) || !current_user_can(RTP_CAP)) {
        return;
    }
    $raw = isset($_POST['rtp']) && is_array($_POST['rtp']) ? wp_unslash($_POST['rtp']) : [];
    update_post_meta($post_id, RTP_META, rtp_sanitize($raw));
    if ($post->post_status === 'publish') {
        rtp_clear_page_cache();
    }
}, 10, 2);

/* ------------------------------------------------------------------ */
/* liste ekranı                                                        */
/* ------------------------------------------------------------------ */

add_filter('manage_' . RTP_POST_TYPE . '_posts_columns', function ($cols) {
    return [
        'cb'          => $cols['cb'],
        'title'       => 'Popup',
        'rtp_status'  => 'Durum',
        'rtp_when'    => 'Zaman',
        'rtp_where'   => 'Nerede',
        'rtp_views'   => 'Görüntülenme',
        'rtp_clicks'  => 'Tıklama',
        'rtp_ctr'     => 'Oran',
    ];
});

add_action('manage_' . RTP_POST_TYPE . '_posts_custom_column', function ($col, $post_id) {
    $post = get_post($post_id);
    $s = rtp_get($post_id);
    switch ($col) {
        case 'rtp_status':
            [$code, $label] = rtp_status_label($post, $s);
            echo '<span class="rtp-status rtp-status-' . esc_attr($code) . '">' . esc_html($label) . '</span>';
            break;
        case 'rtp_when':
            echo esc_html(($s['start'] ? rtp_format_local($s['start']) : 'Hemen') . ' → ' . ($s['end'] ? rtp_format_local($s['end']) : 'süresiz'));
            $extra = [];
            if ($s['days']) {
                $extra[] = implode(', ', array_map(function ($d) { return RTP_DAYS[$d]; }, $s['days']));
            }
            if ($s['time_from']) {
                $extra[] = $s['time_from'] . '–' . $s['time_to'];
            }
            if ($extra) {
                echo '<br><small>' . esc_html(implode(' · ', $extra)) . '</small>';
            }
            break;
        case 'rtp_where':
            $labels = ['all' => 'Bütün sayfalar', 'home' => 'Ana sayfa', 'include' => 'Seçili adresler'];
            echo esc_html($labels[$s['pages']]);
            $langs = ['all' => 'TR + EN', 'tr' => 'Yalnızca TR', 'en' => 'Yalnızca EN'];
            echo '<br><small>' . esc_html($langs[$s['language']]) . '</small>';
            if ($s['device'] !== 'all') {
                echo '<br><small>' . esc_html($s['device'] === 'mobile' ? 'Yalnızca telefon' : 'Yalnızca bilgisayar') . '</small>';
            }
            break;
        case 'rtp_views':
            echo esc_html(number_format_i18n(rtp_stats($post_id)['views']));
            break;
        case 'rtp_clicks':
            echo esc_html(number_format_i18n(rtp_stats($post_id)['clicks']));
            break;
        case 'rtp_ctr':
            echo '%' . esc_html(number_format_i18n(rtp_stats($post_id)['ctr'], 1));
            break;
    }
}, 10, 2);

add_filter('post_row_actions', function ($actions, $post) {
    if ($post->post_type !== RTP_POST_TYPE || !current_user_can(RTP_CAP)) {
        return $actions;
    }
    unset($actions['inline hide-if-no-js'], $actions['view']);
    $actions['rtp_preview'] = 'Önizle: <a target="_blank" rel="noopener" href="' . esc_url(rtp_preview_url($post->ID)) . '">TR</a> / <a target="_blank" rel="noopener" href="' . esc_url(rtp_preview_url($post->ID, 'en')) . '">EN</a>';
    $actions['rtp_duplicate'] = '<a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=rtp_duplicate&post=' . $post->ID), 'rtp_duplicate_' . $post->ID)) . '">Kopyala</a>';
    return $actions;
}, 10, 2);

/* ------------------------------------------------------------------ */
/* kopyalama ve istatistik sıfırlama                                   */
/* ------------------------------------------------------------------ */

function rtp_admin_post_target($action) {
    $post_id = isset($_GET['post']) ? absint($_GET['post']) : 0;
    if (!$post_id || get_post_type($post_id) !== RTP_POST_TYPE || !current_user_can(RTP_CAP)) {
        wp_die('Bu işlem için yetkiniz yok.', 403);
    }
    check_admin_referer($action . '_' . $post_id);
    return $post_id;
}

add_action('admin_post_rtp_duplicate', function () {
    $post_id = rtp_admin_post_target('rtp_duplicate');
    $copy = wp_insert_post([
        'post_type'   => RTP_POST_TYPE,
        'post_status' => 'draft',
        'post_title'  => get_the_title($post_id) . ' (kopya)',
    ]);
    if ($copy && !is_wp_error($copy)) {
        update_post_meta($copy, RTP_META, rtp_get($post_id));
        wp_safe_redirect(admin_url('post.php?action=edit&post=' . $copy));
        exit;
    }
    wp_die('Popup kopyalanamadı.');
});

add_action('admin_post_rtp_reset', function () {
    $post_id = rtp_admin_post_target('rtp_reset');
    rtp_reset_stats($post_id);
    wp_safe_redirect(admin_url('post.php?action=edit&post=' . $post_id));
    exit;
});

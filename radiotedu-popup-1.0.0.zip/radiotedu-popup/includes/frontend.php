<?php
// Sitede gösterim. Sayfa önbelleğe alınabildiği için zamanla ilgili her karar (başlangıç / bitiş,
// gün ve saat penceresi, sıklık) ziyaretçinin tarayıcısında verilir. Sunucu yalnızca o sayfayı
// hedefleyen ve henüz bitmemiş popupları sayfaya ekler.

if (!defined('ABSPATH')) {
    exit;
}

$GLOBALS['rtp_page_popups'] = null;

// isteğin yolu ("/podcast/abc/"); sorgu dizesi olmadan
function rtp_request_path() {
    $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
    $path = wp_parse_url($uri, PHP_URL_PATH);
    return is_string($path) && $path !== '' ? rawurldecode($path) : '/';
}

function rtp_path_matches($path, $patterns) {
    if ($patterns === '') {
        return false;
    }
    $norm = function ($p) {
        $p = rtrim($p, '/');
        return $p === '' ? '/' : $p;
    };
    $path = $norm($path);
    foreach (explode("\n", $patterns) as $pattern) {
        $pattern = $norm(trim($pattern));
        if ($pattern === '') {
            continue;
        }
        $regex = '#^' . str_replace('\*', '.*', preg_quote($pattern, '#')) . '$#i';
        if (preg_match($regex, $path)) {
            return true;
        }
    }
    return false;
}

function rtp_targets_this_page(array $s) {
    $path = rtp_request_path();
    if (rtp_path_matches($path, $s['exclude_paths'])) {
        return false;
    }
    if ($s['pages'] === 'home') {
        return is_front_page() || is_home();
    }
    if ($s['pages'] === 'include') {
        return rtp_path_matches($path, $s['include_paths']);
    }
    return true;
}

function rtp_image($attachment_id) {
    if (!$attachment_id) {
        return null;
    }
    $src = wp_get_attachment_image_src($attachment_id, 'full');
    if (!$src) {
        return null;
    }
    return ['src' => $src[0], 'w' => (int) $src[1], 'h' => (int) $src[2]];
}

// bir popup'ın tarayıcıya giden verisi (yalnızca gösterim için gerekenler)
function rtp_public_data(WP_Post $post, array $s, $lang) {
    $start = rtp_timestamp($s['start']);
    $end = rtp_timestamp($s['end']);
    // düz metin: tarayıcıda yalnızca metin olarak (textContent / aria-label) kullanılır
    $title = trim(wp_strip_all_tags(html_entity_decode(get_the_title($post), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
    // sayfanın diline göre içerik (İngilizce alan boşsa Türkçesi)
    $l = rtp_localized($s, $title, $lang);
    return [
        'id'        => $post->ID,
        'lang'      => $lang,
        'title'     => $l['title'],
        'type'      => $s['type'],
        'desktop'   => rtp_image($l['image_desktop']),
        'mobile'    => rtp_image($l['image_mobile']),
        'alt'       => $l['image_alt'] !== '' ? $l['image_alt'] : $l['title'],
        'link'      => $l['link_url'],
        'newTab'    => (bool) $s['link_new_tab'],
        'button'    => $l['button_text'] !== '' && $l['button_url'] !== '' ? ['text' => $l['button_text'], 'url' => $l['button_url']] : null,
        'start'     => $start === null ? null : $start * 1000,
        'end'       => $end === null ? null : $end * 1000,
        'days'      => $s['days'],
        'from'      => $s['time_from'],
        'to'        => $s['time_to'],
        'device'    => $s['device'],
        'trigger'   => $s['trigger'],
        'delay'     => $s['delay'],
        'scroll'    => $s['scroll'],
        'frequency' => $s['frequency'],
        'freqDays'  => $s['frequency_days'],
        'hideAfterClick' => (bool) $s['hide_after_click'],
        'position'  => $s['position'],
        'animation' => $s['animation'],
        'width'     => $s['width'],
        'mobileWidth' => $s['mobile_width'],
        'radius'    => $s['radius'],
        'overlay'   => $s['overlay_color'],
        'opacity'   => $s['overlay_opacity'],
        'closeOnOverlay' => (bool) $s['close_on_overlay'],
        'showTitle' => (bool) $s['show_title'],
        'autoClose' => $s['auto_close'],
        'priority'  => $s['priority'],
    ];
}

function rtp_preview_id() {
    if (empty($_GET['rtp_preview']) || empty($_GET['_rtpnonce'])) {
        return 0;
    }
    $id = absint($_GET['rtp_preview']);
    if (!$id || !current_user_can(RTP_CAP) || !wp_verify_nonce(sanitize_key(wp_unslash($_GET['_rtpnonce'])), 'rtp_preview_' . $id)) {
        return 0;
    }
    return get_post_type($id) === RTP_POST_TYPE ? $id : 0;
}

function rtp_collect() {
    if ($GLOBALS['rtp_page_popups'] !== null) {
        return $GLOBALS['rtp_page_popups'];
    }
    $list = [];
    $lang = rtp_current_lang();
    $preview = rtp_preview_id();
    if ($preview) {
        $post = get_post($preview);
        $data = rtp_public_data($post, rtp_get($preview), $lang);
        // önizlemede zamanlama, sıklık, cihaz ve tetikleyici atlanır: popup hemen açılır
        $data = array_merge($data, ['start' => null, 'end' => null, 'days' => [], 'from' => '', 'to' => '', 'device' => 'all',
            'trigger' => 'delay', 'delay' => 0, 'frequency' => 'always', 'preview' => true]);
        $list[] = $data;
    } elseif (rtp_options()['enabled'] && !is_admin() && !wp_doing_ajax() && !is_feed() && !is_embed()) {
        $posts = get_posts([
            'post_type'        => RTP_POST_TYPE,
            'post_status'      => 'publish',
            'numberposts'      => 50,
            'suppress_filters' => false,
            'no_found_rows'    => true,
        ]);
        foreach ($posts as $post) {
            $s = rtp_get($post->ID);
            if (rtp_schedule_state($s) === 'ended' || !rtp_targets_this_page($s)) {
                continue;
            }
            if ($s['audience'] === 'guests' && is_user_logged_in()) {
                continue;
            }
            if ($s['audience'] === 'members' && !is_user_logged_in()) {
                continue;
            }
            if ($s['language'] !== 'all' && $s['language'] !== $lang) {
                continue;
            }
            if ($s['type'] === 'image' && !rtp_has_images($s, 'tr') && !rtp_has_images($s, 'en')) {
                continue;
            }
            $list[] = rtp_public_data($post, $s, $lang);
        }
        usort($list, function ($a, $b) {
            return $b['priority'] <=> $a['priority'];
        });
    }
    $GLOBALS['rtp_page_popups'] = $list;
    return $list;
}

add_action('wp_enqueue_scripts', function () {
    if (!rtp_collect()) {
        return;
    }
    wp_enqueue_style('rtp-popup', RTP_URL . 'assets/popup.css', [], rtp_asset_version('popup.css'));
    wp_enqueue_script('rtp-popup', RTP_URL . 'assets/popup.js', [], rtp_asset_version('popup.js'), true);
});

add_action('wp_footer', function () {
    $list = rtp_collect();
    if (!$list) {
        return;
    }
    $o = rtp_options();
    $config = [
        'track'     => $o['stats'] ? esc_url_raw(rest_url('rtp/v1/track')) : '',
        'analytics' => (bool) $o['analytics'],
        'cooldown'  => (int) $o['cooldown'],
        'waitDialogs' => (bool) $o['wait_dialogs'],
        'tz'        => wp_timezone_string(),
        'popups'    => $list,
    ];
    // veriler çalıştırılmayan bir JSON bloğunda durur; içerik HTML olarak yorumlanmaz
    echo '<script type="application/json" id="rtp-data">' . wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    // içerik türündeki popupların gövdesi: kaydedilirken wp_kses_post ile süzülmüş HTML
    foreach ($list as $p) {
        if ($p['type'] !== 'content') {
            continue;
        }
        $l = rtp_localized(rtp_get($p['id']), '', $p['lang']);
        echo '<template id="rtp-content-' . (int) $p['id'] . '">' . do_shortcode(wpautop(wp_kses_post($l['content']))) . '</template>' . "\n";
    }
// WordPress alt bilgi script'lerini 20. sırada basar: veri ondan önce sayfada olmalı
}, 15);

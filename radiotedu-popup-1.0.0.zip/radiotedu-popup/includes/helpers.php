<?php
// Ayar şeması, doğrulama ve zaman hesapları. Bir popup'ın bütün ayarları tek bir meta kaydında
// (RTP_META) dizi olarak tutulur; okunurken her zaman varsayılanlarla birleştirilir.

if (!defined('ABSPATH')) {
    exit;
}

function rtp_defaults() {
    return [
        // içerik
        'type'          => 'image',     // image | content
        'image_desktop' => 0,
        'image_mobile'  => 0,
        'image_alt'     => '',
        'link_url'      => '',
        'link_new_tab'  => 1,
        'content'       => '',
        'button_text'   => '',
        'button_url'    => '',
        // İngilizce sayfalar (/en/...) için karşılıklar; boş bırakılan alan Türkçesiyle doldurulur
        'title_en'         => '',
        'image_desktop_en' => 0,
        'image_mobile_en'  => 0,
        'image_alt_en'     => '',
        'link_url_en'      => '',
        'content_en'       => '',
        'button_text_en'   => '',
        'button_url_en'    => '',
        // zamanlama (sitenin saat diliminde, "Y-m-d\TH:i")
        'start'         => '',
        'end'           => '',
        'days'          => [],          // 0 = pazar ... 6 = cumartesi; boş = her gün
        'time_from'     => '',          // "H:i"; boş = gün boyu
        'time_to'       => '',
        // hedefleme
        'pages'         => 'all',       // all | home | include
        'include_paths' => '',
        'exclude_paths' => '',
        'device'        => 'all',       // all | desktop | mobile
        'audience'      => 'all',       // all | guests | members
        'language'      => 'all',       // all | tr | en
        // tetikleyici
        'trigger'       => 'delay',     // delay | scroll | exit
        'delay'         => 2,           // saniye
        'scroll'        => 40,          // yüzde
        // sıklık
        'frequency'     => 'days',      // always | session | days | once
        'frequency_days'=> 1,
        'hide_after_click' => 1,
        // görünüm
        'position'      => 'center',    // center | bottom-right | bottom-left | bottom-bar
        'animation'     => 'zoom',      // none | fade | zoom | slide
        'width'         => 560,         // px (masaüstü)
        'mobile_width'  => 92,          // % (telefon)
        'radius'        => 14,
        'show_title'    => 1,           // başlık üstte, sitenin haftalık gazete penceresindeki gibi çerçeveyle
        'overlay_color' => '#000000',
        'overlay_opacity' => 60,        // yüzde
        'close_on_overlay' => 1,
        'auto_close'    => 0,           // saniye; 0 = kapatılana kadar
        'priority'      => 10,
    ];
}

function rtp_get($post_id) {
    $saved = get_post_meta($post_id, RTP_META, true);
    return wp_parse_args(is_array($saved) ? $saved : [], rtp_defaults());
}

function rtp_pick($value, array $allowed, $fallback) {
    return in_array($value, $allowed, true) ? $value : $fallback;
}

function rtp_clamp_int($value, $min, $max) {
    return max($min, min($max, (int) $value));
}

// yalnızca http(s) ya da site içi göreli adresler kabul edilir (javascript:, data: vb. reddedilir)
function rtp_clean_url($url) {
    $url = trim((string) $url);
    if ($url === '') {
        return '';
    }
    if ($url[0] === '/' && (strlen($url) === 1 || $url[1] !== '/')) {
        return esc_url_raw(home_url($url));
    }
    // "//alan.com/..." biçimi açık bir https adresine çevrilir
    if (strpos($url, '//') === 0) {
        $url = 'https:' . $url;
    }
    return esc_url_raw($url, ['http', 'https']);
}

function rtp_clean_datetime($value) {
    $value = trim((string) $value);
    if ($value === '') {
        return '';
    }
    $dt = DateTime::createFromFormat('!Y-m-d\TH:i', $value, wp_timezone());
    // 2026-13-40 gibi taşan değerler PHP'de sessizce ileri kayar: yalnızca birebir aynı çıkanlar kabul edilir
    return $dt && $dt->format('Y-m-d\TH:i') === $value ? $value : '';
}

function rtp_clean_time($value) {
    $value = trim((string) $value);
    return preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $value) ? $value : '';
}

// adres kalıpları: her satır bir yol, "*" joker karakter (ör. /podcast/*). Başka karakterler atılır.
function rtp_clean_paths($text) {
    $lines = preg_split('/[\r\n,]+/', (string) $text);
    $out = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $path = wp_parse_url($line, PHP_URL_PATH);
        if (!is_string($path) || $path === '') {
            $path = $line;
        }
        $path = preg_replace('#[^A-Za-z0-9/_\-.*%~]#', '', $path);
        if ($path === '') {
            continue;
        }
        if ($path[0] !== '/' && $path[0] !== '*') {
            $path = '/' . $path;
        }
        $out[] = $path;
        if (count($out) >= 100) {
            break;
        }
    }
    return implode("\n", array_unique($out));
}

function rtp_sanitize(array $in) {
    $d = rtp_defaults();
    $out = [];
    $out['type'] = rtp_pick($in['type'] ?? '', ['image', 'content'], $d['type']);
    $out['image_desktop'] = absint($in['image_desktop'] ?? 0);
    $out['image_mobile'] = absint($in['image_mobile'] ?? 0);
    $out['image_alt'] = sanitize_text_field($in['image_alt'] ?? '');
    $out['link_url'] = rtp_clean_url($in['link_url'] ?? '');
    $out['link_new_tab'] = empty($in['link_new_tab']) ? 0 : 1;
    $out['content'] = wp_kses_post($in['content'] ?? '');
    $out['button_text'] = sanitize_text_field($in['button_text'] ?? '');
    $out['button_url'] = rtp_clean_url($in['button_url'] ?? '');
    $out['title_en'] = sanitize_text_field($in['title_en'] ?? '');
    $out['image_desktop_en'] = absint($in['image_desktop_en'] ?? 0);
    $out['image_mobile_en'] = absint($in['image_mobile_en'] ?? 0);
    $out['image_alt_en'] = sanitize_text_field($in['image_alt_en'] ?? '');
    $out['link_url_en'] = rtp_clean_url($in['link_url_en'] ?? '');
    $out['content_en'] = wp_kses_post($in['content_en'] ?? '');
    $out['button_text_en'] = sanitize_text_field($in['button_text_en'] ?? '');
    $out['button_url_en'] = rtp_clean_url($in['button_url_en'] ?? '');

    $out['start'] = rtp_clean_datetime($in['start'] ?? '');
    $out['end'] = rtp_clean_datetime($in['end'] ?? '');
    $days = isset($in['days']) && is_array($in['days']) ? $in['days'] : [];
    // yalnızca 0-6 arası rakamlar (sayı olmayan bir değer 0'a, yani pazara dönüşmesin)
    $days = array_filter($days, function ($n) {
        return is_scalar($n) && preg_match('/^[0-6]$/', (string) $n);
    });
    $out['days'] = array_values(array_unique(array_map('intval', $days)));
    sort($out['days']);
    if (count($out['days']) === 7) {
        $out['days'] = [];
    }
    $out['time_from'] = rtp_clean_time($in['time_from'] ?? '');
    $out['time_to'] = rtp_clean_time($in['time_to'] ?? '');
    if ($out['time_from'] === '' || $out['time_to'] === '' || $out['time_from'] === $out['time_to']) {
        $out['time_from'] = $out['time_to'] = '';
    }

    $out['pages'] = rtp_pick($in['pages'] ?? '', ['all', 'home', 'include'], $d['pages']);
    $out['include_paths'] = rtp_clean_paths($in['include_paths'] ?? '');
    $out['exclude_paths'] = rtp_clean_paths($in['exclude_paths'] ?? '');
    $out['device'] = rtp_pick($in['device'] ?? '', ['all', 'desktop', 'mobile'], $d['device']);
    $out['audience'] = rtp_pick($in['audience'] ?? '', ['all', 'guests', 'members'], $d['audience']);
    $out['language'] = rtp_pick($in['language'] ?? '', ['all', 'tr', 'en'], $d['language']);

    $out['trigger'] = rtp_pick($in['trigger'] ?? '', ['delay', 'scroll', 'exit'], $d['trigger']);
    $out['delay'] = rtp_clamp_int($in['delay'] ?? $d['delay'], 0, 600);
    $out['scroll'] = rtp_clamp_int($in['scroll'] ?? $d['scroll'], 1, 100);

    $out['frequency'] = rtp_pick($in['frequency'] ?? '', ['always', 'session', 'days', 'once'], $d['frequency']);
    $out['frequency_days'] = rtp_clamp_int($in['frequency_days'] ?? 1, 1, 365);
    $out['hide_after_click'] = empty($in['hide_after_click']) ? 0 : 1;

    $out['position'] = rtp_pick($in['position'] ?? '', ['center', 'bottom-right', 'bottom-left', 'bottom-bar'], $d['position']);
    $out['animation'] = rtp_pick($in['animation'] ?? '', ['none', 'fade', 'zoom', 'slide'], $d['animation']);
    $out['width'] = rtp_clamp_int($in['width'] ?? $d['width'], 200, 1400);
    $out['mobile_width'] = rtp_clamp_int($in['mobile_width'] ?? $d['mobile_width'], 50, 100);
    $out['radius'] = rtp_clamp_int($in['radius'] ?? $d['radius'], 0, 40);
    $color = sanitize_hex_color($in['overlay_color'] ?? '');
    $out['overlay_color'] = $color ? $color : $d['overlay_color'];
    $out['overlay_opacity'] = rtp_clamp_int($in['overlay_opacity'] ?? $d['overlay_opacity'], 0, 95);
    $out['close_on_overlay'] = empty($in['close_on_overlay']) ? 0 : 1;
    $out['show_title'] = empty($in['show_title']) ? 0 : 1;
    $out['auto_close'] = rtp_clamp_int($in['auto_close'] ?? 0, 0, 600);
    $out['priority'] = rtp_clamp_int($in['priority'] ?? $d['priority'], 0, 100);
    return $out;
}

// sitenin saat dilimindeki "Y-m-d\TH:i" -> UNIX zamanı (yoksa null)
function rtp_timestamp($local) {
    if ($local === '') {
        return null;
    }
    $dt = DateTime::createFromFormat('Y-m-d\TH:i', $local, wp_timezone());
    return $dt ? $dt->getTimestamp() : null;
}

/**
 * Yayındaki bir popup'ın şu anki durumu:
 * scheduled (başlamadı), ended (bitti), live (yayında; gün/saat penceresi dışında olabilir)
 */
function rtp_schedule_state(array $s, $now = null) {
    $now = $now === null ? time() : $now;
    $start = rtp_timestamp($s['start']);
    $end = rtp_timestamp($s['end']);
    if ($end !== null && $now >= $end) {
        return 'ended';
    }
    if ($start !== null && $now < $start) {
        return 'scheduled';
    }
    return 'live';
}

// gün ve saat penceresinin içinde mi (sitenin saat diliminde)
function rtp_in_window(array $s, $now = null) {
    $local = new DateTime('@' . ($now === null ? time() : $now));
    $local->setTimezone(wp_timezone());
    $day = (int) $local->format('w');
    $hm = $local->format('H:i');
    if ($s['time_from'] !== '' && $s['time_to'] !== '') {
        if ($s['time_from'] < $s['time_to']) {
            $inside = $hm >= $s['time_from'] && $hm < $s['time_to'];
        } else {
            // gece yarısını aşan aralık (ör. 22:00 - 02:00): sabahki kısım bir önceki günün gösterimidir
            $inside = $hm >= $s['time_from'] || $hm < $s['time_to'];
            if ($hm < $s['time_to']) {
                $day = ($day + 6) % 7;
            }
        }
        if (!$inside) {
            return false;
        }
    }
    return empty($s['days']) || in_array($day, $s['days'], true);
}

function rtp_options() {
    $saved = get_option('rtp_options');
    return wp_parse_args(is_array($saved) ? $saved : [], [
        'enabled'      => 1,  // hepsini birden durdurma anahtarı
        'stats'        => 1,  // görüntülenme / tıklama sayımı
        'analytics'    => 1,  // Google Analytics (gtag / dataLayer) olayları
        'cooldown'     => 0,  // aynı ziyaretçiye iki popup arasında en az kaç dakika
        'wait_dialogs' => 1,  // sayfada başka bir açık pencere varsa (ör. haftalık gazete) bekle
    ]);
}

// popup değişince sayfa önbelleği temizlenir: önbellekteki sayfalar eski popup listesini taşımasın
function rtp_clear_page_cache() {
    if (function_exists('wpfc_clear_all_cache')) {
        wpfc_clear_all_cache(true);
    } elseif (isset($GLOBALS['wp_fastest_cache']) && is_object($GLOBALS['wp_fastest_cache']) && method_exists($GLOBALS['wp_fastest_cache'], 'deleteCache')) {
        $GLOBALS['wp_fastest_cache']->deleteCache(true);
    }
    if (function_exists('rocket_clean_domain')) {
        rocket_clean_domain();
    }
    if (function_exists('w3tc_flush_all')) {
        w3tc_flush_all();
    }
    do_action('litespeed_purge_all');
    do_action('rtp_cache_cleared');
}

// dosyaların sürümü değiştirilme zamanından alınır: güncellemeden sonra tarayıcılar eski kopyayı kullanmaz
function rtp_asset_version($file) {
    $path = RTP_DIR . 'assets/' . $file;
    return file_exists($path) ? RTP_VERSION . '.' . filemtime($path) : RTP_VERSION;
}

// sayfanın dili: sitenin kendi kuralıyla aynı (temadaki radiotedu_current_language: /en/ ile başlayan
// adresler İngilizce). Tema yoksa Polylang, o da yoksa aynı adres kuralı kullanılır.
function rtp_current_lang() {
    if (function_exists('radiotedu_current_language')) {
        $lang = radiotedu_current_language();
    } elseif (function_exists('pll_current_language')) {
        $lang = (string) pll_current_language('slug');
    } else {
        $uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '/';
        $path = (string) wp_parse_url($uri, PHP_URL_PATH);
        $lang = preg_match('#^/en(?:/|$)#', $path) ? 'en' : 'tr';
    }
    return $lang === 'en' ? 'en' : 'tr';
}

function rtp_has_images(array $s, $lang) {
    return $lang === 'en' ? ($s['image_desktop_en'] || $s['image_mobile_en']) : ($s['image_desktop'] || $s['image_mobile']);
}

/**
 * Bir dile göre gösterilecek içerik. İngilizce alanlar boşsa Türkçeleri kullanılır:
 * görseller birlikte (masaüstü + telefon), diğer alanlar tek tek.
 */
function rtp_localized(array $s, $title, $lang) {
    $en = $lang === 'en';
    $pick = function ($key) use ($s, $en) {
        return $en && $s[$key . '_en'] !== '' ? $s[$key . '_en'] : $s[$key];
    };
    $useEnImages = $en && rtp_has_images($s, 'en');
    $enContent = $en && trim(wp_strip_all_tags($s['content_en'])) !== '';
    $button = $en && $s['button_text_en'] !== '' ? [$s['button_text_en'], $s['button_url_en'] !== '' ? $s['button_url_en'] : $s['button_url']] : [$s['button_text'], $s['button_url']];
    return [
        'title'         => $en && $s['title_en'] !== '' ? $s['title_en'] : $title,
        'image_desktop' => $useEnImages ? $s['image_desktop_en'] : $s['image_desktop'],
        'image_mobile'  => $useEnImages ? $s['image_mobile_en'] : $s['image_mobile'],
        'image_alt'     => $pick('image_alt'),
        'link_url'      => $pick('link_url'),
        'content'       => $enContent ? $s['content_en'] : $s['content'],
        'button_text'   => $button[0],
        'button_url'    => $button[1],
    ];
}

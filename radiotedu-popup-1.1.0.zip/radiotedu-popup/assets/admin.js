/* RadioTEDU Popup — düzenleme ekranı: görsel seçici, renk seçici, koşullu alanlar */
(function ($) {
  'use strict';

  var EMPTY = '<span class="rtp-image-empty"><span class="dashicons dashicons-format-image"></span>Görsel seç</span>';

  var setImage = function (field, id, url) {
    field.find('input[type=hidden]').val(id || '');
    var preview = field.find('.rtp-image-preview');
    if (url) {
      preview.addClass('has-image').empty().append($('<img alt="">').attr('src', url));
    } else {
      preview.removeClass('has-image').html(EMPTY);
    }
    field.find('[data-rtp-change], [data-rtp-remove]').prop('hidden', !id);
  };

  // medya kütüphanesinden görsel seçme (kutucuğa ya da "Değiştir"e tıklayınca)
  $(document).on('click', '[data-rtp-pick]', function (e) {
    e.preventDefault();
    var field = $(this).closest('[data-rtp-image]');
    var frame = wp.media({ title: 'Popup görseli seç', button: { text: 'Bu görseli kullan' }, library: { type: 'image' }, multiple: false });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      setImage(field, a.id, (a.sizes && a.sizes.medium && a.sizes.medium.url) || a.url);
    });
    frame.open();
  });

  $(document).on('click', '[data-rtp-remove]', function (e) {
    e.preventDefault();
    setImage($(this).closest('[data-rtp-image]'), '', '');
  });

  // .html dosyasını tarayıcıda okuyup kod kutusuna koyar (sunucuya dosya yüklenmez)
  $(document).on('change', '[data-rtp-html-file]', function () {
    var file = this.files && this.files[0];
    var box = $(this).closest('.rtp-html-field').find('textarea');
    var input = this;
    if (!file) return;
    if (file.size > 300000) { window.alert('Dosya çok büyük (en fazla 300 KB).'); input.value = ''; return; }
    var reader = new FileReader();
    reader.onload = function () {
      if (box.val().trim() && !window.confirm('Kutudaki mevcut HTML, dosyanın içeriğiyle değiştirilsin mi?')) { input.value = ''; return; }
      box.val(String(reader.result)).trigger('change');
      input.value = '';
    };
    reader.readAsText(file, 'utf-8');
  });

  // data-rtp-show="anahtar=değer1,değer2": yalnızca seçim uyunca görünen alanlar
  var valueOf = function (key) {
    var radio = $('input[type=radio][name="rtp[' + key + ']"]:checked');
    if (radio.length) return radio.val();
    return $('[name="rtp[' + key + ']"]').val();
  };
  var refresh = function () {
    $('[data-rtp-show]').each(function () {
      var rule = String($(this).data('rtp-show')).split('=');
      $(this).toggle(rule[1].split(',').indexOf(valueOf(rule[0])) !== -1);
    });
  };
  $(document).on('change', '#poststuff [name^="rtp["]', refresh);

  $(function () {
    refresh();
    if ($.fn.wpColorPicker) $('.rtp-color').wpColorPicker();
  });
})(jQuery);

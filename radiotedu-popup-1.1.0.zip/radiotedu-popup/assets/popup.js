/*
 * RadioTEDU Popup — ziyaretçi tarafı
 * Sayfadaki #rtp-data bloğunu okur, zamanı / cihazı / sıklığı uygun olan en öncelikli popup'ı
 * tetikleyicisi gelince gösterir. Bir sayfada en fazla bir popup açılır.
 * Bütün içerik DOM API ile kurulur; veriden gelen hiçbir metin HTML olarak işlenmez.
 */
(function () {
  'use strict';

  var config;
  var load = function () {
    var dataEl = document.getElementById('rtp-data');
    if (!dataEl) return false;
    try { config = JSON.parse(dataEl.textContent || '{}'); } catch (e) { return false; }
    return !!(config && Array.isArray(config.popups) && config.popups.length);
  };

  var MOBILE_QUERY = '(max-width: 767px)';
  var DAY = 86400000;
  var shown = false;

  /* ---------------------------------------------------------------- */
  /* ziyaretçinin tarayıcısında tutulan kayıtlar (kişisel veri yok)     */
  /* ---------------------------------------------------------------- */

  var store = {
    get: function (area, key) {
      try { return JSON.parse(window[area].getItem(key) || 'null'); } catch (e) { return null; }
    },
    set: function (area, key, value) {
      try { window[area].setItem(key, JSON.stringify(value)); } catch (e) {}
    }
  };
  var seen = function () { var s = store.get('localStorage', 'rtp_seen'); return s && typeof s === 'object' ? s : {}; };
  var sessionSeen = function () { var s = store.get('sessionStorage', 'rtp_session'); return s && typeof s === 'object' ? s : {}; };

  var remember = function (id, field) {
    var all = seen();
    var rec = all[id] && typeof all[id] === 'object' ? all[id] : {};
    rec[field] = Date.now();
    all[id] = rec;
    // eski kayıtlar birikmesin: en fazla 50 popup
    var ids = Object.keys(all);
    if (ids.length > 50) {
      ids.sort(function (a, b) { return (all[a].shown || 0) - (all[b].shown || 0); });
      ids.slice(0, ids.length - 50).forEach(function (k) { delete all[k]; });
    }
    store.set('localStorage', 'rtp_seen', all);
    if (field === 'shown') {
      var ss = sessionSeen();
      ss[id] = 1;
      store.set('sessionStorage', 'rtp_session', ss);
      store.set('localStorage', 'rtp_last', Date.now());
    }
  };

  /* ---------------------------------------------------------------- */
  /* uygunluk                                                          */
  /* ---------------------------------------------------------------- */

  // sitenin saat dilimindeki gün (0 = pazar) ve "SS:DD"
  var siteClock = function (now) {
    var tz = config.tz || '';
    var m = /^([+-])(\d{2}):(\d{2})$/.exec(tz);
    if (m) {
      var offset = (m[1] === '-' ? -1 : 1) * (Number(m[2]) * 60 + Number(m[3]));
      var d = new Date(now + offset * 60000);
      return { day: d.getUTCDay(), hm: pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) };
    }
    try {
      var parts = {};
      new Intl.DateTimeFormat('en-US', { timeZone: tz || undefined, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
        .formatToParts(new Date(now)).forEach(function (p) { parts[p.type] = p.value; });
      var days = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
      return { day: days[parts.weekday], hm: (parts.hour === '24' ? '00' : parts.hour) + ':' + parts.minute };
    } catch (e) {
      var l = new Date(now);
      return { day: l.getDay(), hm: pad(l.getHours()) + ':' + pad(l.getMinutes()) };
    }
  };
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  var inSchedule = function (p, now) {
    if (p.start && now < p.start) return false;
    if (p.end && now >= p.end) return false;
    var c = siteClock(now);
    var day = c.day;
    if (p.from && p.to) {
      var inside;
      if (p.from < p.to) {
        inside = c.hm >= p.from && c.hm < p.to;
      } else {
        // gece yarısını aşan aralık: sabahki kısım bir önceki günün gösterimidir
        inside = c.hm >= p.from || c.hm < p.to;
        if (c.hm < p.to) day = (day + 6) % 7;
      }
      if (!inside) return false;
    }
    return !p.days || !p.days.length || p.days.indexOf(day) !== -1;
  };

  var isMobile = function () { return window.matchMedia && window.matchMedia(MOBILE_QUERY).matches; };

  var deviceOk = function (p) {
    if (p.device === 'desktop' && isMobile()) return false;
    if (p.device === 'mobile' && !isMobile()) return false;
    if (p.type === 'image') return !!(p.desktop || p.mobile);
    if (p.type === 'html') return !!(p.html && String(p.html).trim());
    return true;
  };

  var frequencyOk = function (p, now) {
    if (p.preview) return true;
    var rec = seen()[p.id] || {};
    if (p.hideAfterClick && rec.clicked) return false;
    switch (p.frequency) {
      case 'once': return !rec.shown;
      case 'session': return !sessionSeen()[p.id];
      case 'days': return !rec.shown || now - rec.shown >= (p.freqDays || 1) * DAY;
      default: return true;
    }
  };

  var cooldownOk = function (now) {
    var minutes = Number(config.cooldown) || 0;
    var last = Number(store.get('localStorage', 'rtp_last')) || 0;
    return !minutes || !last || now - last >= minutes * 60000;
  };

  var pick = function () {
    var now = Date.now();
    var preview = config.popups.filter(function (p) { return p.preview; })[0];
    if (preview) return preview;
    if (!cooldownOk(now)) return null;
    for (var i = 0; i < config.popups.length; i++) {
      var p = config.popups[i];
      if (inSchedule(p, now) && deviceOk(p) && frequencyOk(p, now)) return p;
    }
    return null;
  };

  /* ---------------------------------------------------------------- */
  /* istatistik ve Analytics                                           */
  /* ---------------------------------------------------------------- */

  var report = function (p, event) {
    if (p.preview) return;
    if (config.track) {
      try {
        fetch(config.track, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: p.id, event: event }),
          // sayfa kapanırken de gitsin (ör. bağlantıya tıklanıp aynı sekmede yeni sayfa açılınca)
          keepalive: true
        }).catch(function () {});
      } catch (e) {}
    }
    if (config.analytics) {
      var params = { popup_id: String(p.id), popup_name: p.title };
      try {
        if (typeof window.gtag === 'function') window.gtag('event', 'rtp_popup_' + event, params);
        else if (Array.isArray(window.dataLayer)) window.dataLayer.push(Object.assign({ event: 'rtp_popup_' + event }, params));
      } catch (e) {}
    }
  };

  /* ---------------------------------------------------------------- */
  /* gösterim                                                          */
  /* ---------------------------------------------------------------- */

  var el = function (tag, cls, attrs) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (attrs) Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    return n;
  };

  // yalnızca http(s) adresler bağlantı olur
  var safeUrl = function (url) {
    if (!url) return '';
    try {
      var u = new URL(url, document.baseURI);
      return u.protocol === 'http:' || u.protocol === 'https:' ? u.href : '';
    } catch (e) { return ''; }
  };

  // HTML popup'ın çerçeve belgesi: kullanıcının HTML'i + küçük bir köprü script'i.
  // Köprü: içeriğin yüksekliğini bildirir, bağlantı tıklamalarını sayar ve bağlantıları
  // çerçevenin içinde değil sitenin kendisinde (ya da yeni sekmede) açar.
  // data-rtp-close özniteliği taşıyan (ya da href="#kapat" olan) bir öğe popup'ı kapatır.
  var BRIDGE = '<script>(function(){' +
    'var send=function(m){try{parent.postMessage(m,"*")}catch(e){}};' +
    'var size=function(){var d=document.documentElement,b=document.body;send({rtp:"height",value:Math.ceil(Math.max(d.getBoundingClientRect().height,b?b.scrollHeight:0))})};' +
    'addEventListener("load",size);if(window.ResizeObserver){new ResizeObserver(size).observe(document.documentElement)}setTimeout(size,0);' +
    'document.addEventListener("click",function(e){var t=e.target&&e.target.closest?e.target.closest("a,[data-rtp-close]"):null;if(!t)return;' +
    'var h=t.getAttribute("href")||"";if(t.hasAttribute("data-rtp-close")||h==="#kapat"){e.preventDefault();send({rtp:"close"});return}' +
    'if(!h||h.charAt(0)==="#"||/^javascript:/i.test(h))return;if(!t.target)t.target="_top";send({rtp:"click"})},true)' +
    '})()</' + 'script>';
  var htmlDocument = function (html) {
    html = String(html || '');
    var base = '<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0}</style>';
    // tam bir belge geldiyse başlık kısmına, parça geldiyse başa eklenir; köprü en sona
    if (/<head[^>]*>/i.test(html)) html = html.replace(/<head[^>]*>/i, function (m) { return m + base; });
    else html = base + html;
    return /<\/body>/i.test(html) ? html.replace(/<\/body>(?![\s\S]*<\/body>)/i, BRIDGE + '</body>') : html + BRIDGE;
  };

  var hexToRgba = function (hex, opacity) {
    var m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(hex || '');
    var h = m ? m[1] : '000000';
    if (h.length === 3) h = h.replace(/(.)/g, '$1$1');
    var n = parseInt(h, 16);
    return 'rgba(' + (n >> 16 & 255) + ',' + (n >> 8 & 255) + ',' + (n & 255) + ',' + Math.max(0, Math.min(95, Number(opacity) || 0)) / 100 + ')';
  };

  var show = function (p) {
    if (shown) return;
    shown = true;
    var modal = p.position === 'center';
    var mobile = isMobile();
    var root = el('div', 'rtp-root rtp-pos-' + p.position + ' rtp-anim-' + p.animation + ' rtp-type-' + p.type);
    root.style.setProperty('--rtp-width', p.width + 'px');
    root.style.setProperty('--rtp-mobile-width', p.mobileWidth + 'vw');
    root.style.setProperty('--rtp-radius', p.radius + 'px');

    var overlay = null;
    if (modal) {
      overlay = el('div', 'rtp-overlay');
      overlay.style.background = hexToRgba(p.overlay, p.opacity);
      root.appendChild(overlay);
    }
    var box = el('div', 'rtp-box', { role: 'dialog', 'aria-label': p.title || 'Duyuru', tabindex: '-1' });
    if (modal) box.setAttribute('aria-modal', 'true');
    var close = el('button', 'rtp-close', { type: 'button', 'aria-label': 'Kapat', title: 'Kapat' });
    // çarpı CSS ile düğmenin kendi katmanında çizilir (.rtp-close::before): her ekran ölçeğinde tam ortada kalır

    // başlık açıksa: çerçeve, sol üstte ad, sağ üstte kapatma düğmesi
    var framed = !!(p.showTitle && p.title);
    var head = null;
    if (framed) {
      root.classList.add('rtp-framed');
      head = el('div', 'rtp-head');
      var heading = el('span', 'rtp-title');
      heading.textContent = p.title;
      head.appendChild(heading);
      head.appendChild(close);
    }

    var body = el('div', 'rtp-body');
    var clickTarget = null;
    var frame = null;
    var onMessage = null;
    if (p.type === 'image') {
      var img = mobile ? (p.mobile || p.desktop) : (p.desktop || p.mobile);
      var image = el('img', 'rtp-image', { alt: p.alt || '', decoding: 'async' });
      image.src = img.src;
      if (img.w && img.h) { image.width = img.w; image.height = img.h; }
      var link = safeUrl(p.link);
      if (link) {
        var a = el('a', 'rtp-link', { href: link });
        if (p.newTab) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
        a.appendChild(image);
        body.appendChild(a);
        clickTarget = a;
      } else {
        body.appendChild(image);
      }
    } else if (p.type === 'html') {
      // HTML popup: kod, kum havuzlu bir çerçevede çalışır. allow-same-origin YOK: çerçevedeki kod
      // sitenin çerezlerine, oturumuna ve sayfasına erişemez; yalnızca aşağıdaki mesajları gönderebilir.
      frame = el('iframe', 'rtp-html', {
        title: p.title || 'Duyuru',
        sandbox: 'allow-scripts allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation allow-forms',
        referrerpolicy: 'no-referrer',
        loading: 'eager'
      });
      frame.srcdoc = htmlDocument(p.html);
      body.appendChild(frame);
    } else {
      var tpl = document.getElementById('rtp-content-' + p.id);
      var content = el('div', 'rtp-content');
      if (tpl && tpl.content) content.appendChild(tpl.content.cloneNode(true));
      body.appendChild(content);
      if (p.button) {
        var bUrl = safeUrl(p.button.url);
        if (bUrl) {
          var btn = el('a', 'rtp-button', { href: bUrl });
          btn.textContent = p.button.text;
          if (p.newTab) { btn.target = '_blank'; btn.rel = 'noopener noreferrer'; }
          body.appendChild(btn);
          clickTarget = btn;
        }
      }
      content.querySelectorAll('a[href]').forEach(function (a) {
        a.addEventListener('click', function () { onClick(); });
      });
    }
    box.appendChild(head || close);
    box.appendChild(body);
    if (p.autoClose) {
      var bar = el('div', 'rtp-timer');
      bar.style.animationDuration = p.autoClose + 's';
      box.appendChild(bar);
    }
    root.appendChild(box);
    // sitenin kendi pencereleri (haftalık gazete vb.) açık bir <dialog> varken bekler: popup açıkken
    // görünmez bir işaret durur, popup kapanınca onunla birlikte kalkar; iki pencere üst üste açılmaz
    var lock = el('dialog', 'rtp-lock', { 'aria-hidden': 'true' });
    lock.setAttribute('open', '');
    lock.hidden = true;
    lock.style.display = 'none';
    root.appendChild(lock);

    var previouslyFocused = document.activeElement;
    var docEl = document.documentElement;
    var prevOverflow = docEl.style.overflow;
    var closed = false;
    var timers = [];
    var clicked = false;

    var onKey = function (e) {
      if (e.key === 'Escape') { e.preventDefault(); dismiss('close'); return; }
      if (e.key === 'Tab' && modal) {
        var f = box.querySelectorAll('a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (document.activeElement === box || !box.contains(document.activeElement)) { e.preventDefault(); (e.shiftKey ? last : first).focus(); }
        else if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };

    var dismiss = function (reason) {
      if (closed) return;
      closed = true;
      timers.forEach(clearTimeout);
      document.removeEventListener('keydown', onKey, true);
      if (onMessage) window.removeEventListener('message', onMessage);
      if (reason === 'close') report(p, 'close');
      root.classList.remove('rtp-open');
      var finish = function () {
        if (root.parentNode) root.parentNode.removeChild(root);
        if (modal) docEl.style.overflow = prevOverflow;
        if (previouslyFocused && previouslyFocused.focus) { try { previouslyFocused.focus({ preventScroll: true }); } catch (e) {} }
      };
      if (p.animation === 'none') finish(); else timers.push(setTimeout(finish, 260));
    };

    var onClick = function () {
      if (clicked) return;
      clicked = true;
      if (!p.preview) remember(p.id, 'clicked');
      report(p, 'click');
      // aynı sekmede açılan bağlantıda popup kapanır; yeni sekmede açılanda da kapanır
      setTimeout(function () { dismiss('click'); }, 0);
    };
    if (clickTarget) clickTarget.addEventListener('click', onClick);

    // HTML çerçevesinden gelen mesajlar: yalnızca bu popup'ın çerçevesinden ve yalnızca bilinen türler
    if (frame) {
      onMessage = function (e) {
        if (e.source !== frame.contentWindow || !e.data || typeof e.data !== 'object') return;
        if (e.data.rtp === 'height') {
          var h = Math.max(60, Math.min(Number(e.data.value) || 0, innerHeight - (mobile ? 60 : 96)));
          frame.style.height = h + 'px';
        } else if (e.data.rtp === 'click') {
          onClick();
        } else if (e.data.rtp === 'close') {
          dismiss('close');
        }
      };
      window.addEventListener('message', onMessage);
    }

    close.addEventListener('click', function () { dismiss('close'); });
    if (overlay && p.closeOnOverlay) overlay.addEventListener('click', function () { dismiss('close'); });
    document.addEventListener('keydown', onKey, true);

    document.body.appendChild(root);
    if (modal) docEl.style.overflow = 'hidden';
    // bir sonraki karede açılış sınıfı eklenir: geçiş animasyonu çalışsın
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        root.classList.add('rtp-open');
        // odak pencerenin kendisine: klavyeyle Tab ilk düğmeye geçer, fareyle açılışta düğmede halka görünmez
        try { box.focus({ preventScroll: true }); } catch (e) {}
      });
    });
    if (p.autoClose) timers.push(setTimeout(function () { dismiss('auto'); }, p.autoClose * 1000));
    if (!p.preview) remember(p.id, 'shown');
    report(p, 'view');
  };

  /* ---------------------------------------------------------------- */
  /* başka bir pencere açıkken beklemek                                */
  /* ---------------------------------------------------------------- */

  var visible = function (n) {
    if (!n || !n.getClientRects().length) return false;
    var cs = getComputedStyle(n);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && Number(cs.opacity) > 0.05;
  };
  var otherDialogOpen = function () {
    if (!config.waitDialogs) return false;
    var nodes = document.querySelectorAll('dialog[open], [aria-modal="true"], [role="dialog"], [role="alertdialog"], .rt-weekly-promo');
    for (var i = 0; i < nodes.length; i++) {
      if (!nodes[i].closest('.rtp-root') && visible(nodes[i])) {
        var r = nodes[i].getBoundingClientRect();
        // küçük bildirimler (ör. köşedeki çalar) sayılmaz; ekranın belirgin bir kısmını kaplayanlar sayılır
        if (r.width * r.height > innerWidth * innerHeight * 0.08) return true;
      }
    }
    return false;
  };

  var showWhenFree = function (p) {
    var waited = 0;
    var attempt = function () {
      if (shown) return;
      if (!p.preview && otherDialogOpen() && waited < 120000) {
        waited += 1000;
        setTimeout(attempt, 1000);
        return;
      }
      // beklenirken zaman aralığı dolmuş olabilir
      if (!p.preview && !inSchedule(p, Date.now())) return;
      show(p);
    };
    attempt();
  };

  /* ---------------------------------------------------------------- */
  /* tetikleyiciler                                                    */
  /* ---------------------------------------------------------------- */

  var arm = function (p) {
    var fired = false;
    var fire = function () {
      if (fired) return;
      fired = true;
      cleanup();
      showWhenFree(p);
    };
    var listeners = [];
    var on = function (target, type, fn, opts) { target.addEventListener(type, fn, opts); listeners.push([target, type, fn, opts]); };
    var cleanup = function () { listeners.forEach(function (l) { l[0].removeEventListener(l[1], l[2], l[3]); }); };

    var trigger = p.trigger;
    // dokunmatik cihazlarda fare sayfadan çıkamaz: çıkış niyeti yerine gecikme kullanılır
    if (trigger === 'exit' && (isMobile() || !window.matchMedia('(pointer: fine)').matches)) trigger = 'delay';

    if (trigger === 'scroll') {
      var check = function () {
        var h = document.documentElement.scrollHeight - innerHeight;
        var pct = h > 0 ? (scrollY / h) * 100 : 100;
        if (pct >= p.scroll) fire();
      };
      on(window, 'scroll', check, { passive: true });
      check();
    } else if (trigger === 'exit') {
      on(document, 'mouseout', function (e) {
        if (!e.relatedTarget && e.clientY <= 0) fire();
      });
    } else {
      setTimeout(fire, Math.max(0, Number(p.delay) || 0) * 1000);
    }
  };

  // uygun popup yoksa her dakika yeniden bakılır (sayfa açıkken bir zaman aralığı başlayabilir)
  var start = function () {
    // veri bloğu script'ten sonra gelse de (ör. bir optimizasyon eklentisi sırayı değiştirirse) bulunur
    if (!load()) return;
    var p = pick();
    if (p) { arm(p); return; }
    var next = setInterval(function () {
      if (shown) { clearInterval(next); return; }
      var q = pick();
      if (q) { clearInterval(next); arm(q); }
    }, 60000);
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();

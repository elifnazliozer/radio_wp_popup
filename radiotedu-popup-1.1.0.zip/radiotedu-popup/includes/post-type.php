<?php
// "Popuplar" içerik türü. Popuplar yazı gibi tutulur (başlık + ayarlar), siteye ayrı sayfa olarak çıkmaz.

if (!defined('ABSPATH')) {
    exit;
}

function rtp_register_post_type() {
    $cap = RTP_CAP;
    register_post_type(RTP_POST_TYPE, [
        'labels' => [
            'name'               => 'Popup',
            'singular_name'      => 'Popup',
            'menu_name'          => 'Popup',
            'add_new'            => 'Yeni popup',
            'add_new_item'       => 'Yeni popup ekle',
            'edit_item'          => 'Popup\'ı düzenle',
            'new_item'           => 'Yeni popup',
            'view_item'          => 'Popup\'ı görüntüle',
            'search_items'       => 'Popup ara',
            'not_found'          => 'Popup bulunamadı',
            'not_found_in_trash' => 'Çöp kutusunda popup yok',
            'all_items'          => 'Tüm popuplar',
        ],
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_rest'        => false,
        'exclude_from_search' => true,
        'publicly_queryable'  => false,
        'has_archive'         => false,
        'rewrite'             => false,
        'query_var'           => false,
        'menu_position'       => 26,
        'menu_icon'           => 'dashicons-megaphone',
        'supports'            => ['title'],
        // bütün işlemler tek bir yetkiye bağlı (varsayılan: Editör ve üstü)
        'map_meta_cap'        => false,
        'capabilities'        => [
            'edit_post'              => $cap,
            'read_post'              => $cap,
            'delete_post'            => $cap,
            'edit_posts'             => $cap,
            'edit_others_posts'      => $cap,
            'delete_posts'           => $cap,
            'publish_posts'          => $cap,
            'read_private_posts'     => $cap,
            'create_posts'           => $cap,
            'delete_published_posts' => $cap,
            'delete_others_posts'    => $cap,
            'edit_published_posts'   => $cap,
        ],
    ]);
}
add_action('init', 'rtp_register_post_type');

// popup eklenince, değişince ya da silinince sayfa önbelleği temizlenir
function rtp_maybe_clear_cache($post_id) {
    if (get_post_type($post_id) === RTP_POST_TYPE && !wp_is_post_revision($post_id) && !wp_is_post_autosave($post_id)) {
        rtp_clear_page_cache();
    }
}
add_action('transition_post_status', function ($new, $old, $post) {
    if ($post->post_type === RTP_POST_TYPE && ($new === 'publish' || $old === 'publish')) {
        rtp_clear_page_cache();
    }
}, 10, 3);
add_action('before_delete_post', 'rtp_maybe_clear_cache');

<?php
// Popuplar > Ayarlar: bütün popuplar için genel anahtarlar

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_init', function () {
    register_setting('rtp_options_group', 'rtp_options', [
        'type'              => 'array',
        'sanitize_callback' => function ($in) {
            $in = is_array($in) ? $in : [];
            return [
                'enabled'      => empty($in['enabled']) ? 0 : 1,
                'stats'        => empty($in['stats']) ? 0 : 1,
                'analytics'    => empty($in['analytics']) ? 0 : 1,
                'cooldown'     => rtp_clamp_int($in['cooldown'] ?? 0, 0, 10080),
                'wait_dialogs' => empty($in['wait_dialogs']) ? 0 : 1,
            ];
        },
    ]);
});

// genel ayarlar değişince sayfa önbelleği temizlenir
add_action('update_option_rtp_options', 'rtp_clear_page_cache');

add_action('admin_menu', function () {
    add_submenu_page(
        'edit.php?post_type=' . RTP_POST_TYPE,
        'Popup ayarları',
        'Ayarlar',
        'manage_options',
        'rtp-settings',
        'rtp_render_settings_page'
    );
});

function rtp_render_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $o = rtp_options();
    ?>
    <div class="wrap">
        <h1>Popup ayarları</h1>
        <form method="post" action="options.php">
            <?php settings_fields('rtp_options_group'); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">Popuplar</th>
                    <td><label><input type="checkbox" name="rtp_options[enabled]" value="1" <?php checked($o['enabled']); ?>> Popuplar sitede gösterilsin</label>
                        <p class="description">Kapatırsanız hiçbir popup gösterilmez (popuplar silinmez). Acil durdurma için.</p></td>
                </tr>
                <tr>
                    <th scope="row">İstatistik</th>
                    <td><label><input type="checkbox" name="rtp_options[stats]" value="1" <?php checked($o['stats']); ?>> Görüntülenme ve tıklamalar sayılsın</label>
                        <p class="description">Ziyaretçi hakkında kişisel veri tutulmaz; yalnızca popup başına toplam sayılar.</p></td>
                </tr>
                <tr>
                    <th scope="row">Google Analytics</th>
                    <td><label><input type="checkbox" name="rtp_options[analytics]" value="1" <?php checked($o['analytics']); ?>> Sitede Google Analytics varsa <code>rtp_popup_view</code>, <code>rtp_popup_click</code>, <code>rtp_popup_close</code> olayları gönderilsin</label>
                        <p class="description">Olaylar yalnızca sitenin çerez onayı Analytics'e izin verdiyse çalışan mevcut Analytics koduna iletilir.</p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="rtp-cooldown">İki popup arası</label></th>
                    <td><input id="rtp-cooldown" type="number" min="0" max="10080" name="rtp_options[cooldown]" value="<?php echo esc_attr($o['cooldown']); ?>" class="small-text"> dakika
                        <p class="description">Aynı ziyaretçiye bir popup gösterildikten sonra başka bir popup en az bu kadar süre gösterilmez. 0 = sınır yok.</p></td>
                </tr>
                <tr>
                    <th scope="row">Diğer pencereler</th>
                    <td><label><input type="checkbox" name="rtp_options[wait_dialogs]" value="1" <?php checked($o['wait_dialogs']); ?>> Sayfada açık başka bir pencere varsa (çerez onayı, haftalık gazete vb.) o kapanana kadar bekle</label></td>
                </tr>
            </table>
            <?php submit_button('Kaydet'); ?>
        </form>
    </div>
    <?php
}

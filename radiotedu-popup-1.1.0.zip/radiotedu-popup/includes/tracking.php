<?php
// Görüntülenme / tıklama / kapatma sayaçları. Ziyaretçi hakkında hiçbir şey saklanmaz: yalnızca
// popup başına toplamlar ve son 90 günün günlük toplamları tutulur.
//
// Uç herkese açıktır (sayfalar önbellekten geldiği için nonce kullanılamaz). Bu yüzden yalnızca
// yayındaki bir popup'ın sayacını bir artırabilir; başka hiçbir veriyi okuyamaz ya da değiştiremez.

if (!defined('ABSPATH')) {
    exit;
}

const RTP_EVENTS = ['view' => '_rtp_views', 'click' => '_rtp_clicks', 'close' => '_rtp_closes'];

add_action('rest_api_init', function () {
    register_rest_route('rtp/v1', '/track', [
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'args'                => [
            'id'    => ['required' => true, 'type' => 'integer', 'minimum' => 1],
            'event' => ['required' => true, 'type' => 'string', 'enum' => array_keys(RTP_EVENTS)],
        ],
        'callback'            => 'rtp_track',
    ]);
});

function rtp_track(WP_REST_Request $req) {
    $options = rtp_options();
    if (!$options['stats']) {
        return new WP_REST_Response(null, 204);
    }
    // başka bir siteden tarayıcıyla gönderilen sayımlar reddedilir (tarayıcılar Origin başlığını hep ekler)
    $origin = $req->get_header('origin');
    if ($origin && wp_parse_url($origin, PHP_URL_HOST) !== wp_parse_url(home_url(), PHP_URL_HOST)) {
        return new WP_REST_Response(['ok' => false], 403);
    }
    $id = (int) $req['id'];
    $event = (string) $req['event'];
    $post = get_post($id);
    if (!$post || $post->post_type !== RTP_POST_TYPE || $post->post_status !== 'publish') {
        return new WP_REST_Response(['ok' => false], 404);
    }
    rtp_increment($id, RTP_EVENTS[$event]);

    $daily = get_post_meta($id, '_rtp_daily', true);
    $daily = is_array($daily) ? $daily : [];
    $today = wp_date('Y-m-d');
    if (!isset($daily[$today])) {
        $daily[$today] = ['view' => 0, 'click' => 0, 'close' => 0];
    }
    $daily[$today][$event] = (int) ($daily[$today][$event] ?? 0) + 1;
    ksort($daily);
    $daily = array_slice($daily, -90, null, true);
    update_post_meta($id, '_rtp_daily', $daily);

    return new WP_REST_Response(null, 204);
}

// sayaç tek bir SQL ifadesiyle artırılır: aynı anda gelen istekler birbirinin sayısını ezmez
function rtp_increment($post_id, $key) {
    global $wpdb;
    $updated = $wpdb->query($wpdb->prepare(
        "UPDATE {$wpdb->postmeta} SET meta_value = meta_value + 1 WHERE post_id = %d AND meta_key = %s",
        $post_id,
        $key
    ));
    if (!$updated) {
        add_post_meta($post_id, $key, 1, true) || $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->postmeta} SET meta_value = meta_value + 1 WHERE post_id = %d AND meta_key = %s",
            $post_id,
            $key
        ));
    }
    wp_cache_delete($post_id, 'post_meta');
}

function rtp_stats($post_id) {
    $views = (int) get_post_meta($post_id, '_rtp_views', true);
    $clicks = (int) get_post_meta($post_id, '_rtp_clicks', true);
    return [
        'views'  => $views,
        'clicks' => $clicks,
        'closes' => (int) get_post_meta($post_id, '_rtp_closes', true),
        'ctr'    => $views ? round($clicks * 100 / $views, 1) : 0,
    ];
}

function rtp_reset_stats($post_id) {
    foreach (array_merge(array_values(RTP_EVENTS), ['_rtp_daily']) as $key) {
        delete_post_meta($post_id, $key);
    }
}

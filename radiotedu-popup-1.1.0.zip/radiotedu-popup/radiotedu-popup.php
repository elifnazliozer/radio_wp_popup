<?php
/**
 * Plugin Name: RadioTEDU Popup
 * Description: Zamanlanmış popup yönetimi: belirli gün ve saatlerde açılıp kapanan görselli, yazılı ya da HTML popuplar; Türkçe ve İngilizce sayfalar için ayrı içerik, sayfa hedefleme, tetikleyiciler, sıklık sınırı ve istatistikler.
 * Version: 1.1.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: RadioTEDU
 * License: GPL-2.0-or-later
 * Text Domain: radiotedu-popup
 */

if (!defined('ABSPATH')) {
    exit;
}

define('RTP_VERSION', '1.1.0');
define('RTP_FILE', __FILE__);
define('RTP_DIR', plugin_dir_path(__FILE__));
define('RTP_URL', plugin_dir_url(__FILE__));
define('RTP_POST_TYPE', 'rtp_popup');
define('RTP_META', '_rtp_settings');
// popupları yönetebilen yetki: varsayılan olarak Editör ve Yönetici
if (!defined('RTP_CAP')) {
    define('RTP_CAP', 'edit_others_posts');
}

require_once RTP_DIR . 'includes/helpers.php';
require_once RTP_DIR . 'includes/post-type.php';
require_once RTP_DIR . 'includes/settings.php';
require_once RTP_DIR . 'includes/tracking.php';
require_once RTP_DIR . 'includes/frontend.php';
if (is_admin()) {
    require_once RTP_DIR . 'includes/admin.php';
}

register_activation_hook(__FILE__, function () {
    rtp_register_post_type();
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, 'rtp_clear_page_cache');

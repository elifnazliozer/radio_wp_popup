<?php
// Eklenti "Sil" ile kaldırılınca (devre dışı bırakmada değil) popuplar ve ayarlar silinir.

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

$ids = get_posts([
    'post_type'   => 'rtp_popup',
    'post_status' => ['publish', 'future', 'draft', 'pending', 'private', 'trash', 'auto-draft'],
    'numberposts' => -1,
    'fields'      => 'ids',
]);
foreach ($ids as $id) {
    wp_delete_post($id, true);
}
delete_option('rtp_options');
